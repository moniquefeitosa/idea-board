const db = require('./db');

const Idea = db.sequelize.define('banco_de_ideias',{
    nome:{
        type: db.Sequelize.STRING
    },

    ideia:{
        type: db.Sequelize.STRING
    }
})
//Criando tabela
//Idea.sync({force: true})

module.exports = Idea;
