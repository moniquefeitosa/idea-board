const express = require("express"); //incluir modulo | constante para nao poder alterar

const app = express(); //Clonagem do modulo express na variavel app

const handlebars = require("express-handlebars"); // incluindo o modulo handlebars pra facilitar no layout

const Idea = require('./models/Idea'); // conexão com o banco

const bodyParser = require('body-parser'); //body parser seve para poder receber dados de formulário

app.use(bodyParser.urlencoded({ extended: false }));
 
// parse application/json
app.use(bodyParser.json()); // dados do db

app.engine('handlebars', handlebars({defaultLayout: 'main'})) // usar o main como layout principal
app.set('view engine', 'handlebars') 

app.get('/', function(req, res){
    res.render('cadastro'); // renderizando a pagina de cadastro das ideias
})

app.get('/ideias', function(req, res){
    Idea.findAll().then(function(ideia){
       res.render('ideias', {ideias: ideia}); // fazendo a variavel ideia pegar todos os dados do bd
    })
})

app.post('/ideias', function(req,res){
    Idea.create({
        nome: req.body.nome,
        ideia: req.body.ideia
    }).then(function(){
        res.redirect('ideias') //cadastro das ideias e redirecionamento caso positivo
    }).catch(function(erro){
        res.send("Erro: Ideia não cadastrada" + erro)
    })
})

app.get('/del-ideia/:id', function(req, res){
  Idea.destroy({
    where: {'id': req.params.id} //apagar as ideias pelo id delas no db
  }).then(function(){
    res.redirect('/ideias')
  }).catch(function(erro){
    res.send("Ideia não apagada!")
  })
})

app.listen(8080); //porta localhost:8080


